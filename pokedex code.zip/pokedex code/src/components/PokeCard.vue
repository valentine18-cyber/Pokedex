<template>
    <div class="card">
        <div>
         <img :src="'asset/'+pokemon.image" alt=""> 
          <div>
           {{pokemon.name}} 
        </div>  
        </div>
       
        
    </div>
</template>
<script>
export default {
    props: {
        pokemon: {
            type: String
        }
    }
}
</script>
<style scoped>
.card{
    margin: 1em;
    padding:1em;
     border-radius: 15px;
     width: 18vw;
     display: flex;
     justify-content: center;
}

    .lol{
        position: relative;
    }


.valou{
    font-family: Arial, Helvetica, sans-serif;
    font-weight: 700;
    font-size: 18px;
    background-color: aliceblue;
    border: none;
}

.btn{
    position: absolute;
    bottom:2cm;
    display: flex;
    justify-content: center;
    width: 100%;
}

</style> 


   

