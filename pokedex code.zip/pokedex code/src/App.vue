<template>
  <header class="logo">
    <img alt="vue logo" src="./assets/pngegg-8.png">
  </header>
  
  <PokeList>
  </PokeList>
</template>

<script>
import PokeList from './components/PokeList.vue'

export default {
  name: 'App',
  components: {
    PokeList
  }
}
</script>

<style scoped>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}

.logo{
  height: 150px;
  display: flex;
  justify-content: space-around;
  margin: 50px;
}
</style>
